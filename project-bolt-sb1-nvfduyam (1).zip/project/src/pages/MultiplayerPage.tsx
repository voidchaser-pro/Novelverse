import { useState, useEffect, useRef } from 'react';
import {
  Swords,
  Users,
  Bot,
  ChevronLeft,
  Check,
  X,
  Zap,
  Trophy,
  Crown,
  Shield,
  RotateCcw,
  CircleDot,
  Swords as SwordsIcon,
} from 'lucide-react';
import { QUIZZES, LEADERBOARD } from '@/data/mockData';
import type { MatchPlayer, QuizQuestion } from '@/types';
import { useApp } from '@/context/AppContext';
import { PageHeader } from '@/components/UI';

type MatchPhase = 'lobby' | 'countdown' | 'playing' | 'results';

// Pull questions from multiple quizzes for variety
const MATCH_QUESTIONS = QUIZZES.flatMap((q) => q.questions).slice(0, 5);

export function MultiplayerPage() {
  const { navigate, user } = useApp();
  const [phase, setPhase] = useState<MatchPhase>('lobby');
  const [mode, setMode] = useState<'vs-ai' | 'vs-friends'>('vs-ai');
  const [opponents, setOpponents] = useState<MatchPlayer[]>([]);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [timeLeft, setTimeLeft] = useState(20);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const botTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const question: QuizQuestion = MATCH_QUESTIONS[questionIndex];

  function startMatch() {
    const bots: MatchPlayer[] = LEADERBOARD
      .filter((e) => !e.isCurrentUser)
      .slice(0, mode === 'vs-ai' ? 1 : 3)
      .map((e) => ({
        id: e.id,
        username: e.username,
        avatar: e.avatar,
        xp: e.xp,
        level: e.level,
        ready: true,
        score: 0,
      }));

    const selfPlayer: MatchPlayer = {
      id: user.id,
      username: user.username,
      avatar: user.avatar,
      xp: user.xp,
      level: user.level,
      ready: true,
      score: 0,
      isCurrentUser: true,
    };

    setOpponents([selfPlayer, ...bots]);
    setPhase('countdown');
    setCountdown(3);
    setQuestionIndex(0);
  }

  // Countdown
  useEffect(() => {
    if (phase !== 'countdown') return;
    if (countdown <= 0) {
      setPhase('playing');
      return;
    }
    const t = setTimeout(() => setCountdown((c) => c - 1), 800);
    return () => clearTimeout(t);
  }, [phase, countdown]);

  // Question timer
  useEffect(() => {
    if (phase !== 'playing') return;
    setTimeLeft(20);
    setSelectedIndex(null);
    setShowResult(false);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          revealAnswer(null);
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    // Bots answer at random times
    const botDelays = opponents.slice(1).map(() => 3000 + Math.random() * 12000);
    botTimerRef.current = setTimeout(() => {
      // Bots pick answers — higher level = higher accuracy
      setOpponents((prev) =>
        prev.map((p, i) => {
          if (i === 0) return p;
          const accuracy = Math.min(0.85, 0.4 + p.level * 0.015);
          const correct = Math.random() < accuracy;
          const botAnswer = correct ? question.correctIndex : Math.floor(Math.random() * question.options.length);
          const points = correct ? question.xp + 10 : 0;
          return { ...p, selectedAnswer: botAnswer, score: p.score + points, answered: true };
        })
      );
    }, Math.min(...botDelays));

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (botTimerRef.current) clearTimeout(botTimerRef.current);
    };
  }, [phase, questionIndex]); // eslint-disable-line react-hooks/exhaustive-deps

  function revealAnswer(index: number | null) {
    if (timerRef.current) clearInterval(timerRef.current);
    if (botTimerRef.current) clearTimeout(botTimerRef.current);
    setSelectedIndex(index);
    setShowResult(true);

    if (index !== null && index === question.correctIndex) {
      const timeBonus = Math.round(timeLeft * 3);
      const points = question.xp + timeBonus;
      setOpponents((prev) =>
        prev.map((p, i) => (i === 0 ? { ...p, score: p.score + points, selectedAnswer: index, answered: true } : p))
      );
    } else if (index !== null) {
      setOpponents((prev) =>
        prev.map((p, i) => (i === 0 ? { ...p, selectedAnswer: index, answered: true } : p))
      );
    }
  }

  function handleSelect(index: number) {
    if (showResult) return;
    revealAnswer(index);
  }

  function handleNext() {
    if (questionIndex < MATCH_QUESTIONS.length - 1) {
      setQuestionIndex((i) => i + 1);
    } else {
      // Match over
      setPhase('results');
    }
  }

  function handleRematch() {
    setOpponents([]);
    setPhase('lobby');
    setQuestionIndex(0);
    setSelectedIndex(null);
    setShowResult(false);
  }

  // Results screen
  if (phase === 'results') {
    const sorted = [...opponents].sort((a, b) => b.score - a.score);
    const winner = sorted[0];
    const userWon = winner.isCurrentUser;

    return (
      <div className="max-w-2xl mx-auto animate-fade-in-up space-y-6">
        <div className="glass-card p-8 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern opacity-10" />
          {userWon && <div className="absolute top-4 left-1/2 -translate-x-1/2"><Crown className="w-8 h-8 text-amber-400 animate-bounce-in" /></div>}

          <div className={`w-20 h-20 mx-auto rounded-3xl flex items-center justify-center mb-4 mt-4 ${userWon ? 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/30 animate-pulse-glow' : 'bg-gradient-to-br from-slate-400 to-slate-600 shadow-lg'}`}>
            <Trophy className="w-10 h-10 text-white" />
          </div>

          <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-800 dark:text-slate-100">
            {userWon ? 'Victory!' : 'Good Match!'}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
            {userWon ? 'You dominated the quiz arena!' : `${winner.username} took the crown this round.`}
          </p>
        </div>

        {/* Final standings */}
        <div className="glass-card overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-200/60 dark:border-slate-800/60">
            <h3 className="font-display font-bold text-sm text-slate-700 dark:text-slate-200">Final Standings</h3>
          </div>
          <div className="divide-y divide-slate-200/60 dark:divide-slate-800/60">
            {sorted.map((player, i) => (
              <div
                key={player.id}
                className={`flex items-center gap-3 p-4 ${player.isCurrentUser ? 'bg-primary-50/50 dark:bg-primary-950/20' : ''}`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                  i === 0 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400' :
                  i === 1 ? 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300' :
                  i === 2 ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400' :
                  'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                }`}>
                  {i + 1}
                </div>
                <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg flex-shrink-0">
                  {player.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`font-semibold text-sm truncate ${player.isCurrentUser ? 'text-primary-600 dark:text-primary-400' : 'text-slate-800 dark:text-slate-100'}`}>
                    {player.username} {player.isCurrentUser && '(You)'}
                  </p>
                  <p className="text-xs text-slate-400 dark:text-slate-500">Level {player.level}</p>
                </div>
                <div className="flex items-center gap-1.5 text-sm font-bold text-primary-600 dark:text-primary-400 flex-shrink-0">
                  <Zap className="w-4 h-4" />
                  {player.score}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button onClick={handleRematch} className="btn-outline">
            <RotateCcw className="w-4 h-4" />
            Rematch
          </button>
          <button onClick={() => navigate('quizzes')} className="btn-primary">
            <SwordsIcon className="w-4 h-4" />
            New Challenge
          </button>
        </div>
      </div>
    );
  }

  // Playing / countdown
  if (phase === 'countdown' || phase === 'playing') {
    const totalQs = MATCH_QUESTIONS.length;

    return (
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Top bar */}
        <div className="flex items-center justify-between animate-fade-in">
          <button onClick={() => setPhase('lobby')} className="btn-ghost text-sm">
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Forfeit</span>
          </button>
          <span className="text-sm font-bold text-slate-600 dark:text-slate-300">
            Question {questionIndex + 1} / {totalQs}
          </span>
        </div>

        {/* Player scoreboard */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 animate-fade-in">
          {opponents.map((player) => (
            <div
              key={player.id}
              className={`glass-card p-3 text-center relative overflow-hidden ${player.isCurrentUser ? 'ring-2 ring-primary-400/50' : ''}`}
            >
              <div className="w-10 h-10 mx-auto rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg mb-1.5">
                {player.avatar}
              </div>
              <p className="text-xs font-semibold truncate text-slate-700 dark:text-slate-200">
                {player.username}
              </p>
              <p className="text-sm font-bold text-primary-600 dark:text-primary-400 mt-0.5">
                {player.score} XP
              </p>
              {phase === 'playing' && (
                <div className="absolute top-1.5 right-1.5">
                  {showResult && player.answered ? (
                    player.selectedAnswer === question.correctIndex ? (
                      <Check className="w-4 h-4 text-success-500" />
                    ) : (
                      <X className="w-4 h-4 text-error-500" />
                    )
                  ) : player.answered ? (
                    <CircleDot className="w-4 h-4 text-primary-400 animate-pulse" />
                  ) : null}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Countdown overlay */}
        {phase === 'countdown' && (
          <div className="glass-card p-12 sm:p-20 text-center animate-scale-in">
            <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold mb-4">Match starting in…</p>
            <div className="text-7xl sm:text-8xl font-display font-extrabold gradient-text animate-bounce-in" key={countdown}>
              {countdown === 0 ? 'GO!' : countdown}
            </div>
          </div>
        )}

        {/* Question */}
        {phase === 'playing' && question && (
          <>
            {/* Timer bar */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ease-linear ${
                    timeLeft <= 5 ? 'bg-error-500' : timeLeft <= 10 ? 'bg-warning-500' : 'bg-gradient-to-r from-primary-500 to-accent-500'
                  }`}
                  style={{ width: `${(timeLeft / 20) * 100}%` }}
                />
              </div>
              <span className={`text-sm font-bold flex-shrink-0 ${timeLeft <= 5 ? 'text-error-500' : 'text-slate-500 dark:text-slate-400'}`}>
                {timeLeft}s
              </span>
            </div>

            <div key={questionIndex} className="glass-card p-6 sm:p-8 animate-scale-in">
              <h2 className="font-display font-bold text-lg sm:text-xl text-slate-800 dark:text-slate-100 leading-snug text-balance">
                {question.question}
              </h2>

              <div className="grid gap-3 mt-6">
                {question.options.map((option, index) => {
                  const isSelected = selectedIndex === index;
                  const isCorrect = index === question.correctIndex;

                  let stateClass = 'border-slate-200 dark:border-slate-700 hover:border-primary-300 dark:hover:border-primary-700 hover:bg-primary-50/50 dark:hover:bg-primary-950/20';
                  if (showResult && isCorrect) {
                    stateClass = 'border-success-400 bg-success-50 dark:bg-success-950/30 dark:border-success-700';
                  } else if (showResult && isSelected && !isCorrect) {
                    stateClass = 'border-error-400 bg-error-50 dark:bg-error-950/30 dark:border-error-700 animate-shake';
                  } else if (showResult) {
                    stateClass = 'border-slate-200 dark:border-slate-800 opacity-50';
                  }

                  return (
                    <button
                      key={index}
                      onClick={() => handleSelect(index)}
                      disabled={showResult}
                      className={`flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all duration-200 ${stateClass} ${!showResult ? 'active:scale-[0.99]' : ''}`}
                    >
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                        showResult && isCorrect ? 'bg-success-500 text-white' :
                        showResult && isSelected && !isCorrect ? 'bg-error-500 text-white' :
                        'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}>
                        {showResult && isCorrect ? <Check className="w-4 h-4" /> :
                         showResult && isSelected && !isCorrect ? <X className="w-4 h-4" /> :
                         String.fromCharCode(65 + index)}
                      </span>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-200">{option}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {showResult && (
              <button onClick={handleNext} className="btn-primary w-full animate-fade-in-up">
                {questionIndex < totalQs - 1 ? 'Next Question' : 'Final Results'}
              </button>
            )}
          </>
        )}
      </div>
    );
  }

  // Lobby
  return (
    <div className="space-y-6">
      <PageHeader
        title="Multiplayer Arena"
        subtitle="Challenge readers in real-time quiz battles"
        icon={<Swords className="w-6 h-6" />}
      />

      {/* Hero banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-secondary-600 via-primary-700 to-accent-800 p-6 sm:p-8 animate-fade-in-up">
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-white/10 blur-3xl animate-float" />
        <div className="relative flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h2 className="font-display font-extrabold text-xl sm:text-2xl text-white">Ready to Battle?</h2>
            <p className="text-secondary-100 text-sm mt-1.5 max-w-md">
              Face off against opponents in 5 rapid-fire questions. Fastest correct answers earn the most XP.
            </p>
          </div>
          <Swords className="w-16 h-16 text-white/80 flex-shrink-0" />
        </div>
      </div>

      {/* Mode selection */}
      <div className="grid sm:grid-cols-2 gap-4">
        <button
          onClick={() => setMode('vs-ai')}
          className={`glass-card p-6 text-left card-hover transition-all ${mode === 'vs-ai' ? 'ring-2 ring-primary-400' : ''}`}
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-accent-600 flex items-center justify-center text-white shadow-lg shadow-primary-500/30 mb-4">
            <Bot className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-slate-800 dark:text-slate-100">VS AI Opponent</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5">
            Quick match against a computer player matched to your level.
          </p>
          <div className="flex items-center gap-2 mt-4">
            <Shield className="w-4 h-4 text-primary-500" />
            <span className="text-xs font-semibold text-primary-600 dark:text-primary-400">Instant start</span>
          </div>
        </button>

        <button
          onClick={() => setMode('vs-friends')}
          className={`glass-card p-6 text-left card-hover transition-all ${mode === 'vs-friends' ? 'ring-2 ring-primary-400' : ''}`}
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-secondary-500 to-primary-600 flex items-center justify-center text-white shadow-lg shadow-secondary-500/30 mb-4">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-lg text-slate-800 dark:text-slate-100">VS Friends (1v3)</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5">
            Battle 3 opponents in a free-for-all. Most XP wins the round.
          </p>
          <div className="flex items-center gap-2 mt-4">
            <Users className="w-4 h-4 text-secondary-500" />
            <span className="text-xs font-semibold text-secondary-600 dark:text-secondary-400">4 players total</span>
          </div>
        </button>
      </div>

      {/* Match info */}
      <div className="glass-card p-5 animate-fade-in">
        <h3 className="font-display font-bold text-sm text-slate-700 dark:text-slate-200 mb-3">Match Rules</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-display font-bold text-primary-500">5</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Questions</p>
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-accent-500">20s</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Per Question</p>
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-secondary-500">3x</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Speed Bonus</p>
          </div>
        </div>
      </div>

      {/* Start button */}
      <div className="flex justify-center">
        <button onClick={startMatch} className="btn-primary text-base !px-8 !py-3.5">
          <Swords className="w-5 h-5" />
          Start Match
        </button>
      </div>
    </div>
  );
}
