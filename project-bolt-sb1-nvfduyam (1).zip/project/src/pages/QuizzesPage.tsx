import { useState, useMemo } from 'react';
import { Brain, Search, X, Zap, ChevronRight, Trophy, CheckCircle2, Clock } from 'lucide-react';
import { QUIZZES } from '@/data/mockData';
import type { Quiz } from '@/types';
import { PageHeader, EmptyState } from '@/components/UI';
import { NovelCover } from '@/components/NovelCard';
import { useApp } from '@/context/AppContext';

type Difficulty = 'All' | 'Easy' | 'Medium' | 'Hard';

const DIFFICULTY_COLORS: Record<string, string> = {
  Easy: 'bg-success-100 text-success-700 dark:bg-success-900/40 dark:text-success-400',
  Medium: 'bg-warning-100 text-warning-700 dark:bg-warning-900/40 dark:text-warning-400',
  Hard: 'bg-error-100 text-error-700 dark:bg-error-900/40 dark:text-error-400',
};

export function QuizzesPage() {
  const { navigate, user, catalog } = useApp();
  const [query, setQuery] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('All');

  const filtered = useMemo(() => {
    let result = [...QUIZZES];
    if (query.trim()) {
      const q = query.toLowerCase();
      result = result.filter(
        (quiz) => quiz.title.toLowerCase().includes(q) || quiz.novelTitle.toLowerCase().includes(q)
      );
    }
    if (difficulty !== 'All') {
      result = result.filter((q) => q.difficulty === difficulty);
    }
    return result;
  }, [query, difficulty]);

  const totalXpAvailable = QUIZZES.reduce((sum, q) => sum + q.questions.reduce((s, qu) => s + qu.xp, 0), 0);

  return (
    <div className="space-y-6">
      <PageHeader title="Quizzes" subtitle="Test your knowledge and earn XP" icon={<Brain className="w-6 h-6" />} />

      {/* Stats strip */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4 animate-fade-in-up">
        <div className="glass-card p-4 text-center">
          <Trophy className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
          <p className="text-xl font-display font-bold text-slate-800 dark:text-slate-100">{user.quizzesCompleted}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Completed</p>
        </div>
        <div className="glass-card p-4 text-center">
          <CheckCircle2 className="w-5 h-5 text-success-500 mx-auto mb-1.5" />
          <p className="text-xl font-display font-bold text-slate-800 dark:text-slate-100">{user.quizzesWon}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Perfect Scores</p>
        </div>
        <div className="glass-card p-4 text-center">
          <Zap className="w-5 h-5 text-primary-500 mx-auto mb-1.5" />
          <p className="text-xl font-display font-bold text-slate-800 dark:text-slate-100">{totalXpAvailable.toLocaleString()}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">XP Available</p>
        </div>
      </div>

      {/* Search */}
      <div className="flex flex-col sm:flex-row gap-3 animate-fade-in">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search quizzes by title or novel…"
            className="input-field !pl-12 !pr-10"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4 text-slate-400" />
            </button>
          )}
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {(['All', 'Easy', 'Medium', 'Hard'] as Difficulty[]).map((d) => (
            <button
              key={d}
              onClick={() => setDifficulty(d)}
              className={`chip flex-shrink-0 transition-all ${
                difficulty === d
                  ? 'bg-primary-700 text-white shadow-md shadow-primary-500/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      {/* Quiz cards */}
      {filtered.length > 0 ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((quiz) => (
            <QuizCard key={quiz.id} quiz={quiz} onClick={() => navigate('quiz-play', { quizId: quiz.id })} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<Search className="w-7 h-7" />}
          title="No quizzes found"
          description="Try a different search or difficulty filter."
        />
      )}
    </div>
  );
}

function QuizCard({ quiz, onClick }: { quiz: Quiz; onClick: () => void }) {
  const { catalog } = useApp();
  const novel = catalog.find((n) => n.id === quiz.novelId);
  const totalXp = quiz.questions.reduce((s, q) => s + q.xp, 0);

  return (
    <div onClick={onClick} className="glass-card overflow-hidden card-hover cursor-pointer group animate-fade-in-up">
      {/* Header with gradient */}
      <div className={`bg-gradient-to-br ${quiz.color} p-5 relative overflow-hidden`}>
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-white/10 blur-xl" />
        <div className="relative flex items-start justify-between">
          <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white">
            <Brain className="w-6 h-6" />
          </div>
          <span className={`chip ${DIFFICULTY_COLORS[quiz.difficulty]} backdrop-blur-sm`}>
            {quiz.difficulty}
          </span>
        </div>
        <h3 className="relative font-display font-bold text-white text-base mt-4 line-clamp-2 drop-shadow-sm">
          {quiz.title}
        </h3>
      </div>

      {/* Body */}
      <div className="p-5">
        <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-4">{quiz.description}</p>

        {novel && (
          <div className="flex items-center gap-2.5 mb-4 pb-4 border-b border-slate-200/60 dark:border-slate-800/60">
            <NovelCover novel={novel} className="w-8 h-11 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-slate-400 dark:text-slate-500">Based on</p>
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 line-clamp-1">{novel.title}</p>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-xs text-slate-400 dark:text-slate-500 font-medium">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {quiz.questions.length} Qs
            </span>
            <span className="flex items-center gap-1 text-primary-500 font-bold">
              <Zap className="w-3.5 h-3.5" />
              {totalXp} XP
            </span>
          </div>
          <div className="w-9 h-9 rounded-xl bg-primary-500/10 text-primary-500 group-hover:bg-primary-500 group-hover:text-white transition-all flex items-center justify-center">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </div>
  );
}
