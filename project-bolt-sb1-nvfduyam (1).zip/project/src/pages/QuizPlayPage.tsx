import { useState, useEffect, useRef } from 'react';
import {
  Brain,
  Check,
  X,
  ChevronLeft,
  Zap,
  Trophy,
  Clock,
  RotateCcw,
  Sparkles,
  PartyPopper,
} from 'lucide-react';
import { QUIZZES } from '@/data/mockData';
import type { QuizQuestion } from '@/types';
import { useApp } from '@/context/AppContext';

type Phase = 'answering' | 'correct' | 'wrong' | 'finished';

export function QuizPlayPage() {
  const { pageParams, navigate } = useApp();
  const quiz = QUIZZES.find((q) => q.id === pageParams.quizId);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>('answering');
  const [score, setScore] = useState(0);
  const [earnedXp, setEarnedXp] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (phase !== 'answering') return;
    setTimeLeft(30);
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleTimeout();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, phase]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!quiz) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <p className="text-slate-500 dark:text-slate-400">Quiz not found.</p>
        <button onClick={() => navigate('quizzes')} className="btn-primary mt-4">Back to Quizzes</button>
      </div>
    );
  }

  const question: QuizQuestion = quiz.questions[currentIndex];
  const totalQuestions = quiz.questions.length;
  const progressPct = ((currentIndex + (phase !== 'answering' ? 1 : 0)) / totalQuestions) * 100;

  function handleTimeout() {
    setPhase('wrong');
  }

  function handleSelect(index: number) {
    if (phase !== 'answering') return;
    if (timerRef.current) clearInterval(timerRef.current);
    setSelectedIndex(index);
    if (index === question.correctIndex) {
      setPhase('correct');
      setCorrectCount((c) => c + 1);
      const timeBonus = Math.round(timeLeft * 2);
      const xpEarned = question.xp + timeBonus;
      setEarnedXp((xp) => xp + xpEarned);
      setScore((s) => s + xpEarned);
    } else {
      setPhase('wrong');
    }
  }

  function handleNext() {
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex((i) => i + 1);
      setSelectedIndex(null);
      setPhase('answering');
    } else {
      setPhase('finished');
    }
  }

  function handleRestart() {
    setCurrentIndex(0);
    setSelectedIndex(null);
    setPhase('answering');
    setScore(0);
    setEarnedXp(0);
    setCorrectCount(0);
  }

  // Results screen
  if (phase === 'finished') {
    const accuracy = Math.round((correctCount / totalQuestions) * 100);
    const isPerfect = correctCount === totalQuestions;

    return (
      <div className="max-w-2xl mx-auto animate-fade-in-up">
        <div className="glass-card p-8 sm:p-10 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-pattern opacity-10" />
          {isPerfect && (
            <div className="absolute top-4 right-4">
              <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
            </div>
          )}

          <div className={`w-20 h-20 mx-auto rounded-3xl flex items-center justify-center mb-6 ${isPerfect ? 'bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/30 animate-bounce-in' : 'bg-gradient-to-br from-primary-500 to-accent-600 shadow-lg shadow-primary-500/30'}`}>
            {isPerfect ? <Trophy className="w-10 h-10 text-white" /> : <Brain className="w-10 h-10 text-white" />}
          </div>

          <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-slate-800 dark:text-slate-100">
            {isPerfect ? 'Perfect Score!' : 'Quiz Complete!'}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
            {isPerfect ? 'You answered every question correctly. Outstanding!' : 'Great effort! Here\'s how you did.'}
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 my-8">
            <div className="p-4 rounded-2xl bg-success-50 dark:bg-success-950/30">
              <Check className="w-5 h-5 text-success-500 mx-auto mb-1.5" />
              <p className="text-2xl font-display font-bold text-slate-800 dark:text-slate-100">{correctCount}/{totalQuestions}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Correct</p>
            </div>
            <div className="p-4 rounded-2xl bg-primary-50 dark:bg-primary-950/30">
              <Zap className="w-5 h-5 text-primary-500 mx-auto mb-1.5" />
              <p className="text-2xl font-display font-bold text-slate-800 dark:text-slate-100">{earnedXp}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">XP Earned</p>
            </div>
            <div className="p-4 rounded-2xl bg-accent-50 dark:bg-accent-950/30">
              <Trophy className="w-5 h-5 text-accent-500 mx-auto mb-1.5" />
              <p className="text-2xl font-display font-bold text-slate-800 dark:text-slate-100">{accuracy}%</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Accuracy</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={handleRestart} className="btn-outline">
              <RotateCcw className="w-4 h-4" />
              Try Again
            </button>
            <button onClick={() => navigate('quizzes')} className="btn-primary">
              <Brain className="w-4 h-4" />
              More Quizzes
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Top bar */}
      <div className="flex items-center justify-between gap-3 animate-fade-in">
        <button onClick={() => navigate('quizzes')} className="btn-ghost text-sm">
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden sm:inline">Exit</span>
        </button>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary-50 dark:bg-primary-950/40 text-primary-600 dark:text-primary-400 text-sm font-bold">
            <Zap className="w-4 h-4" />
            {earnedXp} XP
          </div>
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-bold ${
            timeLeft <= 10
              ? 'bg-error-50 dark:bg-error-950/40 text-error-600 dark:text-error-400 animate-pulse'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}>
            <Clock className="w-4 h-4" />
            {timeLeft}s
          </div>
        </div>
      </div>

      {/* Progress */}
      <div>
        <div className="flex items-center justify-between text-xs text-slate-400 dark:text-slate-500 font-medium mb-1.5">
          <span>Question {currentIndex + 1} of {totalQuestions}</span>
          <span>{correctCount} correct</span>
        </div>
        <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary-500 to-accent-500 transition-all duration-500 ease-out"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Question card */}
      <div key={currentIndex} className="glass-card p-6 sm:p-8 animate-scale-in">
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r ${quiz.color} text-white text-xs font-bold mb-4`}>
          <Brain className="w-3.5 h-3.5" />
          {quiz.novelTitle}
        </div>

        <h2 className="font-display font-bold text-lg sm:text-xl text-slate-800 dark:text-slate-100 leading-snug text-balance">
          {question.question}
        </h2>

        {/* Options */}
        <div className="grid gap-3 mt-6">
          {question.options.map((option, index) => {
            const isSelected = selectedIndex === index;
            const isCorrect = index === question.correctIndex;
            const showResult = phase === 'correct' || phase === 'wrong';

            let stateClass = 'border-slate-200 dark:border-slate-700 hover:border-primary-300 dark:hover:border-primary-700 hover:bg-primary-50/50 dark:hover:bg-primary-950/20';
            if (showResult && isCorrect) {
              stateClass = 'border-success-400 bg-success-50 dark:bg-success-950/30 dark:border-success-700';
            } else if (showResult && isSelected && !isCorrect) {
              stateClass = 'border-error-400 bg-error-50 dark:bg-error-950/30 dark:border-error-700 animate-shake';
            } else if (showResult) {
              stateClass = 'border-slate-200 dark:border-slate-800 opacity-50';
            }

            return (
              <button
                key={index}
                onClick={() => handleSelect(index)}
                disabled={showResult}
                className={`flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all duration-200 ${stateClass} ${
                  !showResult ? 'active:scale-[0.99]' : ''
                }`}
              >
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0 transition-colors ${
                  showResult && isCorrect ? 'bg-success-500 text-white' :
                  showResult && isSelected && !isCorrect ? 'bg-error-500 text-white' :
                  'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}>
                  {showResult && isCorrect ? <Check className="w-4 h-4" /> :
                   showResult && isSelected && !isCorrect ? <X className="w-4 h-4" /> :
                   String.fromCharCode(65 + index)}
                </span>
                <span className="text-sm font-medium text-slate-700 dark:text-slate-200 flex-1">
                  {option}
                </span>
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {phase !== 'answering' && (
          <div className={`mt-5 p-4 rounded-xl animate-fade-in-up ${
            phase === 'correct' ? 'bg-success-50 dark:bg-success-950/30' : 'bg-error-50 dark:bg-error-950/30'
          }`}>
            <div className="flex items-start gap-3">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                phase === 'correct' ? 'bg-success-500 text-white' : 'bg-error-500 text-white'
              }`}>
                {phase === 'correct' ? <PartyPopper className="w-4 h-4" /> : <X className="w-4 h-4" />}
              </div>
              <div>
                <p className={`font-bold text-sm ${phase === 'correct' ? 'text-success-700 dark:text-success-400' : 'text-error-700 dark:text-error-400'}`}>
                  {phase === 'correct' ? `Correct! +${question.xp + Math.round(timeLeft * 2)} XP` : 'Not quite!'}
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">{question.explanation}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Next button */}
      {phase !== 'answering' && (
        <button onClick={handleNext} className="btn-primary w-full animate-fade-in-up">
          {currentIndex < totalQuestions - 1 ? 'Next Question' : 'See Results'}
        </button>
      )}
    </div>
  );
}
