# Project memory

## Product intent & audience

- Novelverse: reading + gaming platform combining novel discovery, personal libraries, quizzes, multiplayer challenges, and gamification (XP, achievements, leaderboards).
- Two distinct user roles: **administrators** (manage/publish novels & chapters, review submissions) and **readers** (browse/read published content, track progress).
- Admin-only features: novel CRUD, chapter editor, submission review, dashboard stats. Readers never get publishing privileges.

## Brand personality & voice

- Premium gaming-inspired interface; modern, production-worthy, not cookie-cutter.
- Purple-themed dashboard aesthetic carried across app.

## Visual design & UX direction

- Mobile-first responsive layout; light and dark mode both supported.
- Sidebar-driven navigation in `Layout.tsx` with page-parent mapping for active highlighting; admin links rendered only for admin role.
- Cover previews, admin tables with publishing status indicators, sticky save bars in editors.
- Chapter editor uses large serif-font writing area with live word counts and autosave.
- Loading, empty, and error states expected across pages.

## Decisions, constraints & rationale

- Stack: Vite + React, Tailwind, Lucide React icons, `@/` path alias → `src/`. Do not add UI/icon packages unless requested.
- Backend: Supabase (auth, Postgres with RLS, Storage). Reuse existing tables; inspect before changing.
- Existing tables include: `novels`, `chapters`, `profiles` (with `role` column incl. `'admin'`), reading progress, bookmarks, achievements, submissions.
- Phase 2 Quiz Arena (Nov 2026): quizzes/quiz_questions/quiz_attempts/daily_challenges tables. Correct answers + explanations are NOT readable by clients (column-restricted grant) — only `submit_quiz_attempt` reveals them after scoring. Score computed entirely server-side; XP via `grant_xp` (source='quiz', source_key=quiz_id, retries use `quiz_id:retry` and pay only the improvement). `quiz_attempts` UNIQUE(user_id, quiz_id) keeps best score. Gaming achievements (first-victory, puzzle-solver, champion, unstoppable) reactivated and driven by real quiz metrics. Quiz pages load from Supabase (`src/lib/quizzes.ts`). Daily challenge seeded per-day in `daily_challenges`.
- Phase 3 Multiplayer Arena (Nov 2026): mp_rooms/mp_participants/mp_invitations/mp_match_questions/mp_answers/mp_results tables. RLS is SELECT-only for clients (private-room visibility via `mp_can_see_room`); ALL mutations go through SECURITY DEFINER RPCs (`src/lib/multiplayer.ts`). Server picks random questions, opens timed windows, scores answers at submit time (speed bonus), ranks with shared-rank ties, pays XP once per match via grant_xp (source='multiplayer', source_key='<room_id>:<match_number>'). Realtime replication on all six mp_* tables; UI (`MultiplayerPage.tsx`) fully replaced the old bot-based mock. Invitations are by username — no friends table exists yet (reported dependency). Multiplayer wins stat is still 0 in the profile until a profile-stats RPC is added.
- Supabase Storage public `covers` bucket used for novel cover uploads.
- Security enforced server-side via RLS + `SECURITY DEFINER` functions that validate `auth.uid()` and `profiles.role = 'admin'` internally; frontend hiding is not security. Non-admins denied at DB layer even if they reach admin URLs.
- Submission approval does **not** auto-publish; admins retain final publishing control.
- Centralized `PageId` union type in `src/types/index.ts` enumerates route IDs (e.g. `admin-novels`, `admin-novel-editor`).
- Reading pipeline: `record_chapter_read` → `checkAchievements` updates progress, streaks, XP, achievements; duplicate XP prevention handled there.
- Security advisor tolerates WARN-level findings for intentional admin-validated `SECURITY DEFINER` functions; no ERR-level accepted.
- Pre-existing lint errors exist in unrelated files; do not block on them unless newly introduced.

## Open questions & assumptions

- Assumes existing `profiles.role` admin-role system and RLS policies on `novels` already enforce admin-only writes / reader-only-published reads.
- Browser/runtime testing not performed in build environment; verification limited to typecheck + build + security advisor. Manual admin vs. normal-user access testing still pending.
- Outstanding: end-to-end verification of the 10 specified security/functional tests (admin CRUD, cover upload, reader access gating, reading-progress save, achievement updates, existing-feature regression).